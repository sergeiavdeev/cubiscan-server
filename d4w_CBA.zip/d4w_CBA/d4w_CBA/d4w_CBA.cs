using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Threading;
using System.Xml;

/*using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;*/

using System.Reflection;
using System.Runtime.InteropServices;

using RestSharp;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;

////////////////////////////////////
// History


namespace ns_d4w_CBA
{
   
    public class class_d4w_CBA
    {
        ~class_d4w_CBA()
        {
            //tLogWrite(" ~class_d4w_CBA() StatusCode, Message = " + ooRc + ", " + ooRt);
        }

        public RestClient ooClient = new RestClient();
        public string ooBaseUrl = "https://pms-dev.sandpit.wpp.whitecoat.com.au/api";

        string ooFolder;
        string ooName;
        string ooLine;

        // Filled in qInit()
        /*string osProductVendor;
        string osProductName;
        string osProductVersion;
        string osSiteReference;*/


        // Result
        //bool   ooEr;    // True if error
        //bool   ooEnd;   // True if Completed
        string ooRc;    // Cod: "0" = OK else error
        string ooRt;    // Text: "" = OK else error
        string ooJson;
        string ooHeaders;
        string osResponse;    // Response: see TransactionCompleted()

        string ooCmd;
        public string ooFileVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString(); //dll version
        string ooFinalMessage; //= " (DLL FileVersion: " + ooFileVersion + ", Exit ret code): ";
        string ooAPIVersion;
        const string ooErrorException = "-100";

        #region Tools

        //-------------------
        // Right() !!!
        //-------------------
        private string Right(string sV, int iL)
        {
            iL = (sV.Length < iL ? sV.Length : iL);
            string newValue = sV.Substring(sV.Length - iL);
            return newValue;
        }
        //-------------------
        // SubString() !!!
        //-------------------
        private string SubString(string sV, int iI /*index*/, int iL/*SubStr length*/)
        {
            string newValue = "";
            int qV = sV.Length;
            if (iL < 1 || qV < iI || qV < 1) goto EXIT_FUNCTION;
            //
            iL = (iI + iL > qV ? qV - iI : iL);
            if (iL < 1) goto EXIT_FUNCTION;
            //
            newValue = sV.Substring(iI, iL);
        //
        EXIT_FUNCTION:
            return newValue;
        } // SubString()
         
    
        //-------------------
        // tLogWrite = Write Line to Log
        //-------------------
        private string tLogWrite(string asLine)
        {
            //string sFilePath = ooFolder + "d4w_CBA_" + ooName + ".txt"
            string sFilePath = ooFolder + "d4w_CBA_dll_" + ooName + ".txt"
            //d4w_CBA_dll_XXXX
            ;
            using (StreamWriter w = File.AppendText(sFilePath))
            {
                if (asLine == "")
                {
                    w.WriteLine("");
                }
                else
                {
                    //w.WriteLine("{0} {1}", Replace(DateTime.Now.ToString("s"), "T", " "), asLine);
                    w.WriteLine("{0} {1}", DateTime.Now.ToString("s").Replace( "T", " "), asLine);
                    w.Close();
                };
            };
            return "";
        }

        //-------------------
        // tGetValue = Extract tagged Value
        //-------------------
        // Element of structure:
        //  &XX=<value>&
        private string tGetValue(string asLine, string asTag, ref int aiIndex)
        {
            int i, j; // Current positions
            string sValue;
            // - - - - -
            sValue = ""
            ;
            if (aiIndex < 0)
            { aiIndex = 0; goto EXIT_FUNC; }
            ;
            if (aiIndex >= asLine.Length)
            { aiIndex = asLine.Length - 1; goto EXIT_FUNC; }
            ;
            i = asLine.IndexOf(asTag, aiIndex);
            if (i < 0) goto EXIT_FUNC;
            //
            i = i + asTag.Length;
            aiIndex = i;
            if (aiIndex >= asLine.Length)
            { aiIndex = asLine.Length - 1; goto EXIT_FUNC; }
            ;
            //
            j = asLine.IndexOf("&", i);
            if (j < 0) j = asLine.Length - 1;
            //
            sValue = asLine.Substring(i, j - i);
            //
        EXIT_FUNC:
            return sValue;
            //return sValue.Trim(); //AO
        }
        // tGetValue = Extract tagged Value

        //-------------------
        // qReturn() = Construct Ret String
        //-------------------
        private string qReturn(string sCmd)
        {
            string s_rc = ""; // ret code

            //s_rc = "0"; // Correct Interface
            s_rc += "&RC=" + ooRc;
            s_rc += "&RT=" + ooRt;
            s_rc += "&JSON=" + ooJson;
            s_rc += "&HEADER=" + ooHeaders;
            //s_rc += osResponse;
            //s_rc += "&";
            //

            if (osResponse.Length > 0)
            {
                s_rc += osResponse;
            }

            return s_rc;
        } ///// qReturn()

        //-------------------
        // qInit = Init Executor
        //-------------------
        // From PB (order of items is constant):
        //	    &WD  {gnv_app.is_WorkDirectory}
        //      &PC  {gnv_app.is_computer_name}
        //      &pin {1234}
        //      &CertFile {certification file Base64}
        //
        //
        private string qInit(string sLine)
        {
            int i = 0;
            string s_dir = tGetValue(sLine, "&WD=", ref i);  // Work Dir
            string s_nam = tGetValue(sLine, "&PC=", ref i);  // PC name (virtual for Terminal Service)
            string s_pin = tGetValue(sLine, "&pin=", ref i);
            string s_CertFile = tGetValue(sLine, "&CertFile=", ref i);

            if (s_dir == "")
            {
                //ooFolder = @"c:\d4w\"; 
                ooFolder = Directory.GetCurrentDirectory();
            }
            else
            { ooFolder = s_dir; }
            ;
            if (Right(ooFolder, 1) != @"\") ooFolder = ooFolder + @"\";
            //
            ooName = s_nam;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            if (!String.IsNullOrEmpty(s_CertFile))
            {
                string certContent = File.ReadAllText(@s_CertFile);
                string pin = s_pin;

                try
                {
                    byte[] certData = Convert.FromBase64String(certContent);
                    X509Certificate2 cert = new X509Certificate2(certData, pin, X509KeyStorageFlags.UserKeySet);
                    ooClient.ClientCertificates = new X509CertificateCollection() { cert };
                }
                catch
                { 
                }

            }


            //get API Version
            //if (!String.IsNullOrEmpty(ooAPIVersion))
            if (String.IsNullOrEmpty(ooAPIVersion))
            {
                qHealth();
            }
            

            return "0";
        } ///// qInit()

        //-------------------
        // doReturnParams(IRestResponse response) = Construct Ret Strings from "IRestResponse response"
        //-------------------
        private void doReturnParams(IRestResponse response)
        {
            int iResponseStatusCode = (int)response.StatusCode;
            string sResponseStatusCode = response.StatusCode.ToString();

            ooRc = iResponseStatusCode.ToString();
            ooRt = sResponseStatusCode;

            ooJson = response.Content;
            ooHeaders = "";

            osResponse = "";

            if (iResponseStatusCode > 0)
            {
                if (iResponseStatusCode >= 200 && iResponseStatusCode < 300)
                {
                    ooRc = "0";
                    ooRt = "HTTPStatusCode: " + iResponseStatusCode + " [" + sResponseStatusCode + "]";
                }
            }
            else
            {
                ooRc = ooErrorException;
                ooRt = response.ErrorMessage;
            }
            

            var json = new JObject(); 
            //osResponse += "HEADER=";
            foreach (Parameter A in response.Headers)
            {
                json.Add(A.Name, A.Value.ToString());
            }
            //osResponse += json.ToString();
            //osResponse += "&";
            ooHeaders = json.ToString();
        } ///// doReturnParams()

        string checkCertificate(string sPin, string sFile)
        {

            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            string certContent = File.ReadAllText(@sFile);
            string sRetValue = "";

            byte[] certData = Convert.FromBase64String(certContent);
            X509Certificate2 cert = new X509Certificate2(certData, sPin, X509KeyStorageFlags.UserKeySet);

            sRetValue += "NotAfter (Expiry Date) = " + cert.NotAfter.ToString() + "\r\n";
            sRetValue += "NotBefore (Valid Date) = " + cert.NotBefore.ToString() + "\r\n";
            sRetValue += "Version = " + cert.Version.ToString() +"\r\n";
            sRetValue += "Issuer = " + cert.Issuer.ToString() + "\r\n";

            return sRetValue;
        }

        //-------------------
        // qGetCertificateExpityDate
        // From PB (order of items is constant):
        //     &pin {1234}
        //     &CertFile {certification file Base64}
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT 
        //     &EXPIRYDATE
        //-------------------
        private void qGetCertificateExpityDate()
        {
            string sLine = ooLine;
            int i = 0;
            string s_pin = tGetValue(sLine, "&pin=", ref i);
            string s_CertFile = tGetValue(sLine, "&CertFile=", ref i);

            try
            {

                string certContent = File.ReadAllText(@s_CertFile);
                //string sRetValue = "";

                byte[] certData = Convert.FromBase64String(certContent);
                X509Certificate2 cert = new X509Certificate2(certData, s_pin, X509KeyStorageFlags.UserKeySet);

                ooRc = "0";
                ooRt = "OK";
                osResponse = "&EXPIRYDATE=" + cert.NotAfter.ToString() + "&";
            }
            catch (Exception ex)
            {
                ooRc = ooErrorException;
                ooRt = ex.Message;
                //osResponse = "&EXPIRYDATE=" + cert.NotAfter.ToString() + "&";
            }
        }

        //-------------------
        // qGetDllVersion
        // From PB (order of items is constant):
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT 
        //     &DLLVERSION
        //-------------------
        private void qGetDllVersion()
        {
            
            ooRc = "0";
            ooRt = "OK";
            osResponse = "&DLLVERSION=" + ooFileVersion + "&";
        }

        #endregion

        #region Health
        //-------------------
        // qHealth
        // From PB (order of items is constant):
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qHealth()
        {
            RestClient ooClient1 = new RestClient();
            ooClient1.BaseUrl = ooBaseUrl + "/health";
                
            var request = new RestRequest(Method.GET);
            request.Parameters.Clear();

            IRestResponse response = ooClient1.Execute(request);

            doReturnParams(response);

            try
            {
                var obj = JObject.Parse(response.Content);
                ooAPIVersion = obj["releaseVersion"].ToString();
            }
            catch (Exception e){
                ooRt += ", " + e.Message;        
            }
            

            /*ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";

                var obj = JObject.Parse(response.Content);
                ooAPIVersion = obj["releaseVersion"].ToString();
            }*/
        }

        //-------------------
        // qHealthPMS
        // From PB (order of items is constant):
        //     &X-PMS-INTEGRATION-KEY
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qHealthPMS()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_XPMSINTEGRATIONKEY = tGetValue(sLine, "&X-PMS-INTEGRATION-KEY=", ref i);

            RestClient ooClient1 = new RestClient();
            ooClient1.BaseUrl = ooBaseUrl + "/health/pms";

            var request = new RestRequest(Method.GET);
            request.Parameters.Clear();
            request.AddHeader("X-PMS-INTEGRATION-KEY", s_XPMSINTEGRATIONKEY);

            IRestResponse response = ooClient1.Execute(request);

            doReturnParams(response);

            try
            {
                var obj = JObject.Parse(response.Content);
                ooAPIVersion = obj["releaseVersion"].ToString();
            }catch(Exception e)
            {
                ooRt += ", " + e.Message;
            }
            

            /*ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";

                var obj = JObject.Parse(response.Content);
                ooAPIVersion = obj["releaseVersion"].ToString();
            }*/
        }

        #endregion

        #region Invoice

        //-------------------
        // qInvoiceAllGet
        // From PB (order of items is constant):
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceAllGet()
        {
            ooClient.BaseUrl = ooBaseUrl + "/invoice";

            var request = new RestRequest(Method.GET);
            //request.AddParameter("application/json", json, ParameterType.RequestBody);
            //page ????
            //pageSize ????

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            //osResponse += "&JSON=" + response.Content;
            //osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }
            else
            {
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }

            var json = new JObject();
            osResponse += "HEADER=";
            foreach (Parameter A in response.Headers)
            {
                json.Add(A.Name, A.Value.ToString());
            }
            osResponse += json.ToString();
            osResponse += "&";*/
        }

        //-------------------
        // qInvoiceByRefGet
        // From PB (order of items is constant):
        //     &reference
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceByRefGet()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_reference = tGetValue(sLine, "&reference=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice/" + s_reference;

            var request = new RestRequest(Method.GET);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }
            else
            {
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }

            var json = new JObject();
            osResponse += "HEADER=";
            foreach (Parameter A in response.Headers)
            {
                json.Add(A.Name, A.Value.ToString());
            }
            osResponse += json.ToString();
            osResponse += "&";*/
        }

        //-------------------
        // qInvoiceByRefDelete
        // From PB (order of items is constant):
        //     &reference
        //     &IfMatch
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceByRefDelete()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_reference = tGetValue(sLine, "&reference=", ref i);
            string s_IfMatch = tGetValue(sLine, "&IfMatch=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice/" + s_reference;

            var request = new RestRequest(Method.DELETE);
            request.AddHeader("If-Match", s_IfMatch);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }
            else
            {
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }

            var json = new JObject();
            osResponse += "HEADER=";
            foreach (Parameter A in response.Headers)
            {
                json.Add(A.Name, A.Value.ToString());
            }
            osResponse += json.ToString();
            osResponse += "&";*/

        }

        //-------------------
        // qInvoiceByRefApprovePost
        // From PB (order of items is constant):
        //     &reference
        //     &IfMatch - An etag header must be present for concurrency checking
        //     &BODY
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceByRefApprovePost()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_reference = tGetValue(sLine, "&reference=", ref i);
            string s_IfMatch = tGetValue(sLine, "&IfMatch=", ref i);
            string s_BODY = tGetValue(sLine, "&BODY=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice/" + s_reference + "/approve";

            var request = new RestRequest(Method.POST);
            request.AddHeader("If-Match", s_IfMatch);

            var json = JObject.Parse(s_BODY);
            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;

            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qInvoiceByRefRejectPost
        // From PB (order of items is constant):
        //     &reference
        //     &IfMatch - An etag header must be present for concurrency checking
        //     &BODY
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceByRefRejectPost()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_reference = tGetValue(sLine, "&reference=", ref i);
            string s_IfMatch = tGetValue(sLine, "&IfMatch=", ref i);
            string s_BODY = tGetValue(sLine, "&BODY=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice/" + s_reference + "/reject";

            var request = new RestRequest(Method.POST);
            request.AddHeader("If-Match", s_IfMatch);

            var json = JObject.Parse(s_BODY);
            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;

            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qInvoicePost
        // From PB (order of items is constant):
        //     &BODY
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoicePost()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_BODY = tGetValue(sLine, "&BODY=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice";

            var request = new RestRequest(Method.POST);

            var json = JObject.Parse(s_BODY);
            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;

            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qInvoiceByRefPay
        // From PB (order of items is constant):
        //     &reference
        //     &IfMatch - An etag header must be present for concurrency checking
        //     &BODY
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvoiceByRefPay()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_reference = tGetValue(sLine, "&reference=", ref i);
            string s_IfMatch = tGetValue(sLine, "&IfMatch=", ref i);
            string s_BODY = tGetValue(sLine, "&BODY=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/invoice/" + s_reference + "/pay";

            var request = new RestRequest(Method.POST);
            request.AddHeader("If-Match", s_IfMatch);

            var json = JObject.Parse(s_BODY);
            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

            /*            ooRc = ((int)response.StatusCode).ToString();
                        ooRt = response.StatusCode.ToString();
                        osResponse = "";
                        osResponse += "&JSON=" + response.Content;

                        osResponse += "&";

                        if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
                        {
                            ooRc = "0";
                            ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                        }*/
        }

        #endregion

        #region Log

        // qLog
        // From PB (order of items is constant):
        //     &level
        //     &message
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qLog()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_level = tGetValue(sLine, "&level=", ref i);
            string s_message = tGetValue(sLine, "&message=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/log";

            var request = new RestRequest(Method.POST);

            var json = new JObject();
            json.Add("level", s_level);
            json.Add("message", s_message);

            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }*/
        }

        #endregion

        #region Patient
        //-------------------
        // qInvite
        // From PB (order of items is constant):
        //     &mobileNumber
        //     &firstname
        //     &providerNumber
        //     &invoiceReference
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qInvite()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_mobileNumber = tGetValue(sLine, "&mobileNumber=", ref i);
            string s_firstname = tGetValue(sLine, "&firstname=", ref i);
            string s_providerNumber = tGetValue(sLine, "&providerNumber=", ref i);
            string s_invoiceReference = tGetValue(sLine, "&invoiceReference=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/patient/invite";

            var request = new RestRequest(Method.POST);

            var json = new JObject();
            json.Add("mobileNumber", s_mobileNumber);
            json.Add("firstname", s_firstname);
            json.Add("providerNumber", s_providerNumber);
            json.Add("invoiceReference", s_invoiceReference);

            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;
            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qFind
        // From PB (order of items is constant):
        //     &mobileNumber
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qFind()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_mobileNumber = tGetValue(sLine, "&mobileNumber=", ref i);

            //ooClient.BaseUrl = ooBaseUrl + "/patient/find" + s_mobileNumber;
            ooClient.BaseUrl = ooBaseUrl + "/patient/find?mobileNumber=" + s_mobileNumber;

            var request = new RestRequest(Method.GET);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;
            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qCard_tokenize
        // From PB (order of items is constant):
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qCard_tokenize()
        {
            ooClient.BaseUrl = ooBaseUrl + "/patient/card/tokenize";

            var request = new RestRequest(Method.GET);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;
            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        //-------------------
        // qCard_verify
        // From PB (order of items is constant):
        //     &cardToken
        //     &verification
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qCard_verify()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_cardToken = tGetValue(sLine, "&cardToken=", ref i);
            string s_verification = tGetValue(sLine, "&verification=", ref i);

            ooClient.BaseUrl = ooBaseUrl + "/patient/card/verify";

            var request = new RestRequest(Method.POST);

            var json = new JObject();
            json.Add("cardToken", s_cardToken);
            json.Add("verification", s_verification);

            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            osResponse += "&JSON=" + response.Content;
            osResponse += "&";

            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
            }*/
        }

        #endregion

        #region Report

        #endregion

        #region Setup
        //-------------------
        // qCertificate
        // From PB (order of items is constant):
        //     &pin
        //     &pmsInstanceId
        //     &pmsInstanceUserId
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT 
        //     &JSON
        //     &HEADER
        //-------------------
        private void qCertificate()
        {
            string sLine = ooLine;
            //string s_rc;
            int i = 0;
            string s_pin = tGetValue(sLine, "&pin=", ref i);
            string s_pmsInstanceId = tGetValue(sLine, "&pmsInstanceId=", ref i);
            string s_pmsInstanceUserId = tGetValue(sLine, "&pmsInstanceUserId=", ref i);

            RestClient ooClient1 = new RestClient();
            ooClient1.BaseUrl = ooBaseUrl + "/setup/certificate";

            var request = new RestRequest(Method.POST);

            var json = new JObject();
            json.Add("pin", s_pin);
            json.Add("pmsInstanceId", s_pmsInstanceId);
            json.Add("pmsInstanceUserId", s_pmsInstanceUserId);

            request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient1.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }
            else
            {
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }*/
        }

        // qTerminal
        // From PB (order of items is constant):
        //
        //  To PB (order of items is constant):
        //     &RC
        //     &RT
        //     &JSON
        //     &HEADER
        //-------------------
        private void qTerminal()
        {
            ooClient.BaseUrl = ooBaseUrl + "/setup/terminal";

            var request = new RestRequest(Method.GET);

            //var json = new JObject();

            //request.AddParameter("application/json", json, ParameterType.RequestBody);

            IRestResponse response = ooClient.Execute(request);

            doReturnParams(response);

/*            ooRc = ((int)response.StatusCode).ToString();
            ooRt = response.StatusCode.ToString();
            osResponse = "";
            if (((int)response.StatusCode) >= 200 && ((int)response.StatusCode) < 300)
            {
                ooRc = "0";
                ooRt = "HTTPStatusCode: " + ((int)response.StatusCode).ToString() + " [" + response.StatusCode.ToString() + "]";
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }
            else
            {
                osResponse += "&JSON=" + response.Content;
                osResponse += "&";
            }*/
        }

        #endregion


        //-------------------
        // D4W_CBA()
        //-------------------
        public string d4w_CBA(string sCmd, string sLine)
        {
            string s_rc = ""; // ret code
            ooCmd = sCmd;

            //ooFinalMessage = " (API Version: " + ooAPIVersion + ", DLL FileVersion: " + ooFileVersion + ", Exit ret code): ";
            //ooFinalMessage = " (API Version: " + ooAPIVersion + ", DLL FileVersion: " + ooFileVersion + "): ";
            ooFinalMessage = " (API Version: " + ooAPIVersion + ", DLL Version: " + ooFileVersion + "): ";

            if (sCmd == "INIT")
            { }    // qINIT cannot write to log - it is not defined - so do it after call
            else
            {
                if (sLine == "") 
                {
                    tLogWrite(sCmd + ": " + "no input parameters");
                }
                else
                {
                    tLogWrite(sCmd + ": " + sLine);
                };

            }; 
            //
            ooLine = sLine;
            osResponse = "";
            //
            switch (sCmd)
            {
               case "INIT":
                   //ooEr = false;   // no error
                   //ooEnd = false;
                   ooRc = "0";
                   ooRt = "";
                    //
                   s_rc = qInit(sLine);
                   tLogWrite(""); // Empty Line
                   s_rc = qReturn(sCmd);
                   break;
               //Health
               case "HEALTH":
                   qHealth();
                   s_rc = qReturn(sCmd);
                   break;
               case "HEALTHPMS":
                   qHealthPMS();
                   s_rc = qReturn(sCmd);
                   break;
               //Invoice
               case "INVOICEALLGET":
                   qInvoiceAllGet();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEBYREFGET":
                   qInvoiceByRefGet();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEBYREFDELETE":
                   qInvoiceByRefDelete();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEBYREFAPPROVEPOST":
                   qInvoiceByRefApprovePost();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEBYREFREJECTPOST":
                   qInvoiceByRefRejectPost();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEPOST":
                   qInvoicePost();
                   s_rc = qReturn(sCmd);
                   break;
               case "INVOICEPAY":
                   qInvoiceByRefPay();
                   s_rc = qReturn(sCmd);
                   break;
               //Log
               case "LOG":
                   qLog();
                   s_rc = qReturn(sCmd);
                   break;
               //Patient
               case "INVITE":
                   qInvite();
                   s_rc = qReturn(sCmd);
                   break;
               case "FIND":
                   qFind();
                   s_rc = qReturn(sCmd);
                   break;
               case "CARD_TOKENIZE":
                   qCard_tokenize();
                   s_rc = qReturn(sCmd);
                   break;
               case "CARD_VERIFY":
                   qCard_verify();
                   s_rc = qReturn(sCmd);
                   break;
               //Report
               //Setup
               case "CERTIFICATE":
                   qCertificate();
                   s_rc = qReturn(sCmd);
                   break;
               case "TERMINAL":
                   qTerminal();
                   s_rc = qReturn(sCmd);
                   break;
               //Tools
               case "GETCERTIFICATEEXPIRYDATE":
                   qGetCertificateExpityDate();
                   s_rc = qReturn(sCmd);
                   break;
               case "GETDLLVERSION":
                   qGetDllVersion();
                   s_rc = qReturn(sCmd);
                   break;
               case "ANSR":
                   s_rc = qReturn(sCmd);
                   break;
               default:
                    tLogWrite(sCmd + " unrecognized");
                break;
            };

            if (sCmd != "INIT")
            {
                tLogWrite(sCmd + ooFinalMessage + s_rc);
            };
            return s_rc;
        }
    }   // public class class_d4w_CBA
}
